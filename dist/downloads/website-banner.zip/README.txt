Ideas Into Impact · Banner / 创意成效 · 网站横幅
1600 × 600 pixels · RGB 8-bit · 3 pixel layers

1. Open the PSD in PhotoCraft using File > Open.
2. Background, decoration, placeholder and sample lettering are separate pixel layers.
3. To change words, hide the layer named "Sample lettering - hide and replace" and
   add your own text with the Type tool. PSD sample lettering is rasterized, NOT live text.
4. Replace the decorative image/shape placeholder with your own image on a new layer.
5. Save a copy, reopen it, then export PNG or JPEG. PNG is a ready-to-use flattened image.
6. Optional SVG source keeps text elements editable in a vector editor. Font substitution
   can alter layout; SVG support in PhotoCraft is not asserted. No font files are included.

Checks: PSD decoded and layers/composite checked with psd-tools; PNG decoded with Pillow.
Not tested inside the PhotoCraft desktop app. No smart objects or live text are promised.

使用：在 PhotoCraft 打开 PSD。背景、装饰、占位图和示例文字各自分层。
修改文字时隐藏“Sample lettering - hide and replace”图层，再用文字工具输入。
PSD 示例文字是像素图层，不是可直接编辑的文字图层。PNG 为可直接使用的平面图。
SVG 为可选矢量源文件，可在矢量编辑器中修改文字，本站不宣称 PhotoCraft 支持 SVG。
检查：已用程序读取 PSD 图层与合成图、解码 PNG；尚未在 PhotoCraft 应用内实测。
请阅读 LICENSE.txt。
